#include "pilha.h"

// Diego Moreno Fontana Loureiro - 2025102224
// Arthur Moreira Ferreira - 2025100246
// Thiago Fabrício Ribondi Marcarini -  2025102249
// Murilo Farias Guimarães - 2025100244


ListaGen *ExcluiGen(ListaGen*L,void (*cb)(void*)){
    if(L==NULL) return L;
    ListaGen*aux=L;
    L=aux->prox;
    cb(aux->info);
    free(aux);
    return L;
}

ListaGen* CriaNOGen(ListaGen*L,void*info){
    ListaGen*novo=(ListaGen*)calloc(1,sizeof(ListaGen));
    if(novo==NULL){
        exit(1);
    }
    novo->prox=L;
    L=novo;
    novo->info=info;
    return L;
}



